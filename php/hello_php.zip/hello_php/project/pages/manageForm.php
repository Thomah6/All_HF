<?php
header('Location: form.php?msg=Enregistré&success=true');
?>