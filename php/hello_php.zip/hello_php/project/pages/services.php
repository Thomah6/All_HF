<?php
$title = "Services";
include __DIR__ . '/../includes/header.inc.php';
?>

<h1>Nos Services</h1>

<?php
include __DIR__ . '/../includes/footer.inc.php';
?>