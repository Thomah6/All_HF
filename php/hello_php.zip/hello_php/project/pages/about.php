<?php
    $title = "About";
    $host = $_SERVER['HTTP_HOST'];
    include __DIR__ . '/../includes/header.inc.php';
    ?>
    <h1>Inclusion de fichiers</h1>
   
</nav>


<?php

include __DIR__ . '/../includes/footer.inc.php';
?>