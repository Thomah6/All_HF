<footer>

<p>copyright &copy; 2025</p>
</footer>
</body>
</html>