<template>

<footer class="bg-white dark:bg-neutral-800 border-t border-gray-200 dark:border-neutral-700 mt-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div class="flex flex-wrap justify-center gap-4 text-sm text-gray-500 dark:text-gray-400">
          <a href="docs.html" class="hover:text-gray-700 dark:hover:text-gray-300">Documentation</a>
          <a href="settings.html" class="hover:text-gray-700 dark:hover:text-gray-300">Paramètres</a>
          <a href="logout.html" class="hover:text-gray-700 dark:hover:text-gray-300">Déconnexion</a>
        </div>
        <p class="text-center text-xs sm:text-sm text-gray-400 dark:text-gray-500">&copy; 2023 FetchYourKeys. Tous droits réservés.</p>
      </div>
    </div>
  </footer>

</template>