# FetchYourKeys - Gestion Sécurisée des Clés API

![FetchYourKeys](https://images.unsplash.com/photo-1579113800032-c38bd7635818?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&q=80)

## 📋 Table des Matières

- [Introduction](#-introduction)
- [Fonctionnalités](#-fonctionnalités)
- [Architecture](#-architecture)
- [Installation](#-installation)
- [Utilisation](#-utilisation)
- [Sécurité](#-sécurité)
- [API Reference](#-api-reference)
- [Contribution](#-contribution)
- [License](#-license)

## 🚀 Introduction

**FetchYourKeys** est une application web innovante conçue pour résoudre le problème de gestion des clés API. Elle permet aux développeurs de stocker, organiser et accéder à leurs clés API de manière sécurisée depuis n'importe quel appareil.

### Le Problème

Les développeurs doivent souvent gérer des dizaines de clés API pour différents services. Ces clés sont généralement:
- Éparpillées dans différents projets
- Stockées en clair dans des variables d'environnement
- Difficiles à retrouver et à mettre à jour
- À risque en cas de fuite ou de compromission

### La Solution

FetchYourKeys offre:
- Un stockage centralisé et chiffré de toutes vos clés API
- Un accès sécurisé via une unique clé maître
- Une interface intuitive pour gérer et organiser vos clés
- Un playground pour tester vos APIs facilement

## ✨ Fonctionnalités

### 🔐 Gestion Sécurisée des Clés
- Chiffrement de bout en bout des clés API
- Stockage sécurisé avec Supabase
- Contrôle d'accès granulaire

### 🌐 Accessibilité Universelle
- Accès à vos clés depuis n'importe quel appareil
- Interface responsive adaptée à tous les écrans
- Synchronisation en temps réel

### 🧪 Playground API
- Testez vos APIs directement depuis l'interface
- Visualisez les réponses en temps réel
- Générez automatiquement du code pour différents langages

### 🔌 Intégration Simplifiée
- API unique pour accéder à toutes vos clés
- Exemples de code pour plusieurs langages (cURL, JavaScript, Node.js, Python, etc.)
- Documentation complète et détaillée

## 🏗 Architecture

### Stack Technique
- **Frontend**: HTML, Tailwind CSS, JavaScript vanilla
- **Backend**: Supabase (Base de données, Authentification, Edge Functions)
- **Stockage**: PostgreSQL avec chiffrement au repos
- **Déploiement**: Vercel/Netlify (frontend), Supabase (backend)

### Schéma de la Base de Données

```sql
CREATE TABLE users (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE api_keys (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  encrypted_value TEXT NOT NULL,
  service_name TEXT,
  description TEXT,
  tags TEXT[],
  is_active BOOLEAN DEFAULT TRUE,
  last_used TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE master_keys (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  encrypted_value TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

## 🛠 Installation

### Prérequis
- Compte Supabase
- Node.js (pour le développement local)
- Git

### Étapes d'Installation

1. **Cloner le dépôt**
   ```bash
   git clone https://github.com/votre-username/fetchyourkeys.git
   cd fetchyourkeys
   ```

2. **Configurer Supabase**
   - Créez un nouveau projet sur [Supabase](https://supabase.com)
   - Récupérez l'URL et la clé API
   - Exécutez le script SQL fourni pour créer les tables

3. **Configurer les variables d'environnement**
   ```bash
   cp .env.example .env
   ```
   Remplissez les variables avec vos informations Supabase

4. **Lancer l'application**
   ```bash
   # Développement local avec un serveur HTTP simple
   python -m http.server 8000
   # ou
   npx serve
   ```

## 📖 Utilisation

### Ajouter une Clé API

1. Connectez-vous à votre compte FetchYourKeys
2. Cliquez sur "API Keys" dans la sidebar
3. Sélectionnez "Add Key"
4. Remplissez les informations:
   - Nom de la clé
   - Valeur de la clé
   - Service (OpenAI, Stripe, Google Cloud, etc.)
   - Description (optionnel)
   - Tags (optionnel)

5. La clé est automatiquement chiffrée et stockée de manière sécurisée

### Récupérer une Clé API

Via l'interface:
1. Naviguez vers la section "API Keys"
2. Trouvez la clé souhaitée
3. Copiez la valeur (déchiffrée temporairement pour l'affichage)

Via l'API:
```bash
curl -X GET "https://api.fetchyourkeys.com/v1/keys/OPENAI_API_KEY" \
  -H "Authorization: Bearer VOTRE_CLE_MAITRE"
```

### Utiliser dans un Projet

```javascript
// Exemple avec fetch
const response = await fetch('https://api.fetchyourkeys.com/v1/keys/OPENAI_API_KEY', {
  headers: {
    'Authorization': 'Bearer VOTRE_CLE_MAITRE'
  }
});
const data = await response.json();
const openAIApiKey = data.value;

// Utilisation avec OpenAI
const openai = new OpenAI(openAIApiKey);
// ... reste du code
```

## 🔒 Sécurité

### Chiffrement
- Toutes les clés API sont chiffrées avec AES-256-GCM
- Une clé maître par utilisateur est utilisée pour le chiffrement
- La clé maître est elle-même chiffrée avec une clé dérivée du mot de passe

### Bonnes Pratiques Implémentées
- Authentification forte avec Supabase Auth
- Journalisation des accès et des utilisations de clés
- Rotation automatique des clés (optionnelle)
- Pas de stockage en clair des clés sensibles

### Mesures de Protection
- Limitation du taux d'appels API
- Validation des entrées utilisateur
- Prévention des attaques par injection
- Cookies sécurisés et HTTPOnly

## 📚 API Reference

### Endpoints Principaux

#### Récupérer une clé
```
GET /v1/keys/:key_name
Headers: 
  Authorization: Bearer <master_key>
```

#### Lister toutes les clés
```
GET /v1/keys
Headers: 
  Authorization: Bearer <master_key>
```

#### Ajouter une nouvelle clé
```
POST /v1/keys
Headers: 
  Authorization: Bearer <master_key>
Body:
{
  "name": "key_name",
  "value": "actual_key_value",
  "service": "service_name",
  "description": "optional description"
}
```

#### Mettre à jour une clé
```
PUT /v1/keys/:key_name
Headers: 
  Authorization: Bearer <master_key>
Body:
{
  "value": "new_key_value",
  "service": "updated_service_name"
}
```

#### Supprimer une clé
```
DELETE /v1/keys/:key_name
Headers: 
  Authorization: Bearer <master_key>
```

## 🤝 Contribution

Les contributions sont les bienvenues! Voici comment vous pouvez aider:

1. Forkez le projet
2. Créez une branche pour votre fonctionnalité (`git checkout -b feature/AmazingFeature`)
3. Committez vos changements (`git commit -m 'Add some AmazingFeature'`)
4. Pushez vers la branche (`git push origin feature/AmazingFeature`)
5. Ouvrez une Pull Request

### Améliorations Futures
- Application mobile
- Plugins pour les éditeurs de code (VS Code, IntelliJ)
- Intégrations avec des services populaires (GitHub, GitLab)
- Interface en ligne de commande (CLI)

## 📄 License

Ce projet est sous licence MIT. Voir le fichier `LICENSE` pour plus de détails.

## 🙋‍♂️ Support

Si vous avez des questions ou des problèmes:
1. Consultez la [documentation](https://docs.fetchyourkeys.com)
2. Ouvrez une [issue](https://github.com/votre-username/fetchyourkeys/issues)
3. Contactez-nous par email: support@fetchyourkeys.com

---

**FetchYourKeys** - Ne perdez plus jamais vos clés API! 🔑
