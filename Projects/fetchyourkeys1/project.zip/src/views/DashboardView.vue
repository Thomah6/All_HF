<script setup>
import {ref} from 'vue'
import Header from '@/components/Header.vue'

</script>
<template>

  <!-- Main content -->
  <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <!-- Banner -->
    <div class="bg-gradient-to-r from-red-600 to-indigo-700 rounded-xl shadow-md p-6 mb-8 text-white">
      <div class="flex flex-col md:flex-row md:items-center md:justify-between">
        <div class="mb-4 md:mb-0">
          <h2 class="text-2xl font-bold">Bienvenue sur FetchYourKeys</h2>
          <p class="mt-1 opacity-90">Gérez vos clés API en toute sécurité depuis un seul endroit</p>
        </div>
        <a href="keys-add.html" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-red-700 bg-white hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500">
          <svg class="-ml-1 mr-2 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
          </svg>
          Ajouter une clé
        </a>
      </div>
    </div>

    <!-- Quick Start -->
    <section class="mb-8">
      <div class="bg-white dark:bg-neutral-800 border border-gray-200 dark:border-neutral-700 rounded-xl shadow-sm p-4">
        <div class="flex items-center justify-between">
          <h2 class="text-lg font-semibold text-gray-900 dark:text-white">Démarrage rapide</h2>
          <a href="docs.html" class="text-sm text-red-600 dark:text-red-400 hover:underline">Documentation</a>
        </div>

        <div class="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
          <div class="md:col-span-2">
            <label class="text-xs text-gray-500 dark:text-neutral-400">Nom de la clé</label>
            <select id="qs-key" class="mt-1 w-full px-3 py-2 rounded-lg text-sm border border-gray-300 dark:border-neutral-700 bg-white dark:bg-neutral-800"></select>
            <p id="qs-key-empty" class="mt-1 text-xs text-gray-500 dark:text-neutral-400 hidden">Aucune clé. <a class="text-red-600 dark:text-red-400 hover:underline" href="keys-add.html">Ajouter une clé</a>.</p>
          </div>
          <div>
            <label class="text-xs text-gray-500 dark:text-neutral-400">Master key</label>
            <input id="qs-master" type="text" readonly placeholder="<MASTER_KEY>" class="mt-1 w-full px-3 py-2 rounded-lg text-sm border border-gray-300 dark:border-neutral-700 bg-white dark:bg-neutral-800" />
            <p class="mt-1 text-xs text-gray-500 dark:text-neutral-400">Générer/voir: <a class="text-red-600 dark:text-red-400 hover:underline" href="master-keys.html">Master Key</a></p>
          </div>
        </div>

        <div class="mt-4 rounded-lg border border-gray-200 dark:border-neutral-700 overflow-hidden">
          <div class="flex items-center justify-between px-3 py-2 bg-gray-50 dark:bg-neutral-800/60 border-b border-gray-200 dark:border-neutral-700">
            <div id="qs-tabs" role="tablist" aria-label="Langage" class="inline-flex items-center overflow-hidden rounded-md">
              <button type="button" data-lang="curl" role="tab" aria-selected="true" class="px-3 py-1.5 text-xs sm:text-sm bg-red-600 text-white">cURL</button>
              <button type="button" data-lang="js" role="tab" aria-selected="false" class="px-3 py-1.5 text-xs sm:text-sm">JavaScript</button>
              <button type="button" data-lang="python" role="tab" aria-selected="false" class="px-3 py-1.5 text-xs sm:text-sm">Python</button>
            </div>
            <button id="qs-copy" class="inline-flex items-center gap-1 px-3 py-1.5 rounded-md text-xs sm:text-sm border border-gray-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 hover:bg-gray-50 dark:hover:bg-neutral-700">
              <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16h8M8 12h8M8 8h8M4 6a2 2 0 012-2h8l4 4v10a2 2 0 01-2 2H6a2 2 0 01-2-2z"/></svg>
              <span>Copier</span>
            </button>
          </div>
          <pre class="p-3 bg-neutral-900 text-neutral-100 overflow-x-auto text-sm"><code id="qs-code" class="language-bash"></code></pre>
        </div>
      </div>
    </section>

    <!-- Stats grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <div class="stat-card bg-white dark:bg-neutral-800 rounded-xl shadow-md p-6">
        <div class="flex items-center">
          <div class="p-3 rounded-lg bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400">
            <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"></path>
            </svg>
          </div>
          <div class="ml-4">
            <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Clés API</p>
            <p class="text-2xl font-semibold text-gray-900 dark:text-white"><span id="stat-keys">—</span></p>
          </div>
        </div>
      </div>

      <div class="stat-card bg-white dark:bg-neutral-800 rounded-xl shadow-md p-6">
        <div class="flex items-center">
          <div class="p-3 rounded-lg bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400">
            <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01"></path>
            </svg>
          </div>
          <div class="ml-4">
            <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Services actifs</p>
            <p class="text-2xl font-semibold text-gray-900 dark:text-white"><span id="stat-services">—</span></p>
          </div>
        </div>
      </div>

      <div class="stat-card bg-white dark:bg-neutral-800 rounded-xl shadow-md p-6">
        <div class="flex items-center">
          <div class="p-3 rounded-lg bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400">
            <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
            </svg>
          </div>
          <div class="ml-4">
            <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Requêtes (24h)</p>
            <p class="text-2xl font-semibold text-gray-900 dark:text-white"><span id="stat-requests24h">—</span></p>
          </div>
        </div>
      </div>

      <div class="stat-card bg-white dark:bg-neutral-800 rounded-xl shadow-md p-6">
        <div class="flex items-center">
          <div class="p-3 rounded-lg bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400">
            <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
            </svg>
          </div>
          <div class="ml-4">
            <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Échecs (24h)</p>
            <p class="text-2xl font-semibold text-gray-900 dark:text-white"><span id="stat-failures24h">—</span></p>
          </div>
        </div>
      </div>
    </div>

    <!-- Services section -->
    <div class="mb-8">
      <div class="flex items-center justify-between mb-4">
        <h2 class="text-lg font-semibold text-gray-900 dark:text-white">Services Actifs</h2>
        <a href="services.html" class="text-sm text-red-600 dark:text-red-400 hover:underline">Gérer les services</a>
      </div>
      <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <div class="service-logo flex items-center justify-center p-4 bg-white dark:bg-neutral-800 border border-gray-200 dark:border-neutral-700 rounded-xl shadow-sm">
          <img src="https://cdn.svgporn.com/logos/openai.svg" alt="OpenAI Logo" class="h-8 w-8">
        </div>
        <div class="service-logo flex items-center justify-center p-4 bg-white dark:bg-neutral-800 border border-gray-200 dark:border-neutral-700 rounded-xl shadow-sm">
          <img src="https://cdn.svgporn.com/logos/stripe.svg" alt="Stripe Logo" class="h-8 w-8">
        </div>
        <div class="service-logo flex items-center justify-center p-4 bg-white dark:bg-neutral-800 border border-gray-200 dark:border-neutral-700 rounded-xl shadow-sm">
          <img src="https://cdn.svgporn.com/logos/github-icon.svg" alt="GitHub Logo" class="h-8 w-8">
        </div>
        <div class="service-logo flex items-center justify-center p-4 bg-white dark:bg-neutral-800 border border-gray-200 dark:border-neutral-700 rounded-xl shadow-sm">
          <img src="https://cdn.svgporn.com/logos/google-cloud.svg" alt="Google Cloud Logo" class="h-8 w-8">
        </div>
        <div class="service-logo flex items-center justify-center p-4 bg-white dark:bg-neutral-800 border border-gray-200 dark:border-neutral-700 rounded-xl shadow-sm">
          <img src="https://cdn.svgporn.com/logos/notion-icon.svg" alt="Notion Logo" class="h-8 w-8">
        </div>
        <a href="services.html" class="service-logo flex items-center justify-center p-4 bg-gray-100 dark:bg-neutral-800/50 border-2 border-dashed border-gray-300 dark:border-neutral-600 rounded-xl shadow-sm hover:bg-gray-200 dark:hover:bg-neutral-700 transition-colors">
          <svg class="h-6 w-6 text-gray-500 dark:text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
          </svg>
        </a>
      </div>
    </div>

    <!-- Recent logs section -->
    <div>
      <div class="flex items-center justify-between mb-4">
        <h2 class="text-lg font-semibold text-gray-900 dark:text-white">Derniers Appels API</h2>
        <a href="logs.html" class="text-sm text-red-600 dark:text-red-400 hover:underline">Voir tous les logs</a>
      </div>
      <div class="bg-white dark:bg-neutral-800 border border-gray-200 dark:border-neutral-700 rounded-xl shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200 dark:divide-neutral-700">
            <thead class="bg-gray-50 dark:bg-neutral-700">
              <tr>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Service</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Clé</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Statut</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">IP</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Date</th>
              </tr>
            </thead>
            <tbody id="recent-logs-tbody" class="bg-white dark:bg-neutral-800 divide-y divide-gray-200 dark:divide-neutral-700"></tbody>
          </table>
        </div>
      </div>
    </div>
  </main>
</template>