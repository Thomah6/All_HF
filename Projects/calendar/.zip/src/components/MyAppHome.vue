<script setup>
import img from '@/assets/img/undraw_calendar.svg'
</script>
<template>
        <div class="text-center">
<h1 class="font-bold text-3xl pb-8 text-gray-500">Welcome to MyApp🎉</h1>
        <img :src="img" class="w-sm mx-auto">
</div>
</template>