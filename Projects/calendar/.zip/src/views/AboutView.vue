<script setup>
</script>
<template>
    <div class="text-center">
        "Contenu du About"

    </div>

</template>