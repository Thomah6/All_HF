<script setup>
</script>
<template>
    <div class="text-center">
        "Contenu du home"
    </div>
</template>
<style scoped>
</style>