<script setup>
import Nav from '@/components/Nav.vue'
</script>

<template>
  <Nav />
    <router-view />

</template>

<style scoped></style>
